// Project: SimpleChat
// Part: Server
// File: R
// Note: Resource File
// Author: Hurray Zhu
// Time: 2014.10.28
// E-mail: i@ihurray.com
// Web-site: http://blog.ihurray.com
// GitHub: https://github.com/Hurray0/ketang/tree/master/Distributional_Computing/lab1


public class R {
	//常量
	public static final int PORT = 8000;//服务器端口
	public static final String IPADDRESS = "localhost";
	public static final String MENU = "1.群聊\n2.私聊\n3.退出登录\n请输入你的选项\n";
	public static final int TIME_CLEAN_MILLIS = 1000;//清理周期
}